package controller;

public class RestuarantAdmin {
    
}
