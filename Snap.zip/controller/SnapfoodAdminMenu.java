package controller;

public class SnapfoodAdminMenu {
    
}
