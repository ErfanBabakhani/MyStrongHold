package view;

import controller.MainController;

public class MainView {
    protected MainController mainController=new MainController();

}