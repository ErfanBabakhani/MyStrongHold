package org.example;

import org.example.view.Commands;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Commands commands=new Commands();
        commands.start();
    }
}