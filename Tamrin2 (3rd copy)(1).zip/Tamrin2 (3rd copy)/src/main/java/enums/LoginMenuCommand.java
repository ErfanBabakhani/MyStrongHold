package enums;
import java.util.regex.Pattern;

public enum LoginMenuCommand {

    register("a"),
    isStrongPass("^((?=.{8,}$)(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[\\*\\.\\!\\@\\$\\%\\^\\&\\(\\)\\{\\}\\[\\]\\:\\;\\<\\>\\,\\?\\/\\~\\_\\+\\-\\=\\|]).+)$");
    private Pattern pattern;

    LoginMenuCommand(String pattern) {
        setThePattern(pattern);
    }

    public Pattern getPattern() {
        return pattern;
    }

    private void setThePattern(String pattern) {
        this.pattern = Pattern.compile(pattern);
    }
}
