package view;

import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.ProfileAvatar;

import java.io.FileNotFoundException;

public class ProfileMenu {
    private Stage maintStage;
    private Pane pane;

    public ProfileMenu(Pane pane, Stage maintStage) {
        this.maintStage = maintStage;
        this.pane = pane;
    }

    public void start() throws FileNotFoundException {
        maintStage.setScene(new Scene(pane));
        setAllAvatars();
    }

    public void setAllAvatars() throws FileNotFoundException {
        ProfileAvatar profileAvatar1 = new ProfileAvatar(0, ProfileMenu.class.getResource("/Image/A1.png").toExternalForm());
        ProfileAvatar profileAvatar2 = new ProfileAvatar(100, ProfileMenu.class.getResource("/Image/A2.png").toExternalForm());
        ProfileAvatar profileAvatar3 = new ProfileAvatar(200, ProfileMenu.class.getResource("/Image/A3.png").toExternalForm());
        ProfileAvatar profileAvatar4 = new ProfileAvatar(300, ProfileMenu.class.getResource("/Image/A4.png").toExternalForm());
        ProfileAvatar profileAvatar5 = new ProfileAvatar(400, ProfileMenu.class.getResource("/Image/A5.png").toExternalForm());
        ProfileAvatar profileAvatar6 = new ProfileAvatar(500, ProfileMenu.class.getResource("/Image/A6.png").toExternalForm());
//        ProfileAvatar profileAvatarTest = new ProfileAvatar("/home/erfan-b/Untitled.jpeg");

        pane.getChildren().add(profileAvatar1);
        pane.getChildren().add(profileAvatar2);
        pane.getChildren().add(profileAvatar3);
        pane.getChildren().add(profileAvatar4);
        pane.getChildren().add(profileAvatar5);
        pane.getChildren().add(profileAvatar6);
//        pane.getChildren().add(profileAvatarTest);

    }
    //TODO
    // public void setBackground(){
//        Background background=new Background(new BackgroundImage(new Image()));
//        pane.setBackground();
    // }

//    private static void copyFileUsingStream(File source, File dest) throws IOException {
//        InputStream is = null;
//        OutputStream os = null;
//        try {
//            is = new FileInputStream(source);
//            os = new FileOutputStream(dest);
//            byte[] buffer = new byte[1024];
//            int length;
//            while ((length = is.read(buffer)) > 0) {
//                os.write(buffer, 0, length);
//            }
//        } finally {
//            is.close();
//            os.close();
//        }
//    }
}
