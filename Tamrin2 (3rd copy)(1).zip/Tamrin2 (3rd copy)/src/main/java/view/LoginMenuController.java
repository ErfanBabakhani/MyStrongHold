package view;

import controller.CheckController;
import controller.LoginController;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import model.DataBase;
import model.User;

import java.io.IOException;

public class LoginMenuController {
    public PasswordField password;
    public Label showMessage;
    @FXML
    private TextField username;

    public void register(MouseEvent mouseEvent) throws IOException {
        String username = this.username.getText();
        String password = this.password.getText();
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Password error");
        alert.setContentText("Password weak");
        if (!CheckController.checkThePassword(password))
            alert.showAndWait();
        else {
            boolean[] check = new boolean[1];
            check[0] = true;
            String out = LoginController.register(username, password, check);
            if (!check[0]) {
                alert.setHeaderText("repetitive username!");
                alert.setContentText(out);
                alert.showAndWait();
            } else {
                DataBase.setLoginedUser(DataBase.getUserNameByName(username));
                changeSecen();
            }
        }
    }

    public void initialize() {
        username.textProperty().addListener(((observable, oldValue, newValue) -> {
            showMessage.setText("Hello " + newValue);
        }));
    }

    public void reset(MouseEvent mouseEvent) {
        username.setText("");
        password.setText("");

    }

    public void login(MouseEvent mouseEvent) throws IOException {
        User user = DataBase.getUserNameByName(username.getText());
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("No user");
        alert.setContentText("This user not found");
        if (user == null) {
            alert.showAndWait();
            return;
        } else if (!user.getPassword().equals(password.getText())) {
            alert.setTitle("Invalid password");
            alert.setContentText("Please enter true password");
            alert.showAndWait();
        }
        DataBase.setLoginedUser(user);
        changeSecen();
    }

    public void skip(MouseEvent mouseEvent) throws IOException {
        DataBase.setLoginedUser(new User("Guest", "123"));
        changeSecen();
    }

    public void changeSecen() throws IOException {
        Pane pane = FXMLLoader.load(LoginController.class.getResource("/FXML/ProfileMenu.fxml"));
        ProfileMenu profileMenu = new ProfileMenu(pane, DataBase.getStage());
        profileMenu.start();
    }
}
