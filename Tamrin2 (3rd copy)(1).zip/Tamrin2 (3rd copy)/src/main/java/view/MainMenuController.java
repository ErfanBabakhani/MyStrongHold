package view;

import controller.CheckController;
import controller.LoginController;
import controller.MainController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.DataBase;
import model.User;

import java.io.IOException;
import java.util.ArrayList;

public class MainMenuController {
    public TextField ballNumbers;
    public TextField map;
    public TextField shoutKey;
    public TextField freezeKey;
    public TextField level;


    public Pane changeSecen(String url) throws IOException {
        return FXMLLoader.load(LoginController.class.getResource(url));
    }

    public void newGame(MouseEvent mouseEvent) throws IOException {
        DataBase.getMediaPlayer().stop();
        Pane pane = changeSecen("/FXML/GameMenu.fxml");
        GameMenu gameMenu = new GameMenu(pane, DataBase.getStage());
        gameMenu.start();
    }

    public void loadGame(MouseEvent mouseEvent) {
    }

    public void profileMenu(MouseEvent mouseEvent) throws IOException {
        Pane pane = changeSecen("/FXML/ProfileMenu.fxml");
        ProfileMenu profileMenu = new ProfileMenu(pane, DataBase.getStage());
        profileMenu.start();
    }

    public void Score_Table(MouseEvent mouseEvent) throws IOException {
        Pane pane = FXMLLoader.load(MainMenuController.class.getResource("/FXML/ScoreTable.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(pane));
        pane.getChildren().add(setTheChartOfGeeks());
        pane.getChildren().add(setTheChartLabel());
        pane.getChildren().add(setTheLabelOfAllRankUser());
        if (!DataBase.getLoginedUser().getGame().isMute())
            DataBase.getMediaPlayer().setAutoPlay(true);
        stage.show();
    }

    private Label setTheLabelOfAllRankUser() {
        Label label = new Label();
        String text = "";
        ArrayList<User> ranks = MainController.getTheRankUsers();
        for (int i = 0; i < ranks.size(); i++) {
            text += "Name is :\t" + ranks.get(i).getUsername() + "\tScore is :\t" + ranks.get(i).getScore() + "\tLast game end time per Millis : " + ranks.get(i).getTheLastGameEndTime() + "\n";
        }
        label.setText(text);
        label.setLayoutX(300);
        return label;
    }

    public void setting() throws IOException {
        Pane pane = changeSecen("/FXML/Setting.fxml");
        DataBase.getStage().setScene(new Scene(pane));
    }


    public BarChart<String, Number> setTheChartOfGeeks() {
        ArrayList<User> ranks = MainController.getTheRankUsers();
        System.out.println(ranks.size());
        int firstScore = 0;
        int secondScore = 0;
        int thirdScore = 0;
        String firstRank = "noun";
        String secondRank = "noun";
        String thirdRank = "noun";
        if (ranks.size() > 0) {
            firstScore = ranks.get(0).getScore();
            firstRank = ranks.get(0).getUsername();
        }
        if (ranks.size() > 1) {
            secondScore = ranks.get(1).getScore();
            secondRank = ranks.get(1).getUsername();

        }
        if (ranks.size() > 2) {
            thirdScore = ranks.get(2).getScore();
            thirdRank = ranks.get(2).getUsername();
        }
        NumberAxis yAxis = new NumberAxis(0, 100, 5);
        CategoryAxis xAxis = new CategoryAxis();
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setMaxHeight(40);
        barChart.setMaxWidth(40);
        barChart.setLayoutX(40);
        barChart.setLayoutY(40);
        XYChart.Series series = new XYChart.Series();
        XYChart.Series series2 = new XYChart.Series();
        XYChart.Series series3 = new XYChart.Series();

        series.getData().add(new XYChart.Data<>("First", firstScore));
        series2.getData().add(new XYChart.Data<>("Second", secondScore));
        series3.getData().add(new XYChart.Data<>("Third", thirdScore));
        barChart.getData().add(series);
        barChart.getData().add(series2);
        barChart.getData().add(series3);
        return barChart;
    }

    public LineChart<Number, Number> setTheChartLabel() {
        ArrayList<User> ranks = MainController.getTheRankUsers();
        NumberAxis yAxis = new NumberAxis(0, 100, 5);
        NumberAxis xAxis = new NumberAxis(0, 10, 1);
        LineChart<Number, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setMaxHeight(40);
        lineChart.setMaxWidth(40);
        lineChart.setLayoutX(40);
        lineChart.setLayoutY(200);
        XYChart.Series series = new XYChart.Series();
        for (int i = 0; i < ranks.size() && i < 10; i++) {
            series.getData().add(new XYChart.Data<>((i + 1), ranks.get(i).getScore()));
        }
        lineChart.getData().add(series);
        return lineChart;
    }

    public void back() {
        DataBase.getStage().setScene(DataBase.getMainMenuScene());
    }

    public void selectBallNumbers(MouseEvent mouseEvent) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Level error");
        alert.setContentText("Please enter a valid number more than 0");
        if (ballNumbers.getText() == null) {
            alert.showAndWait();
            return;
        } else if (!CheckController.isNumber(ballNumbers.getText())) {
            alert.showAndWait();
            return;
        }
        int ballNo = Integer.parseInt(ballNumbers.getText());
        if (ballNo < 1) {
            alert.showAndWait();

        } else {
            DataBase.getLoginedUser().getGame().setPlayerBalls(ballNo);
            alert.setAlertType(Alert.AlertType.INFORMATION);
            alert.setTitle("Successful");
            alert.setContentText("We set the level successfully");
            alert.showAndWait();
        }
    }

    public void mute(MouseEvent mouseEvent) {
        DataBase.getLoginedUser().getGame().setMute(true);
        DataBase.getMediaPlayer().setAutoPlay(false);
        DataBase.getMediaPlayer().stop();
        DataBase.getLoginedUser().getGame().setMute(true);
    }

    public void unMute(MouseEvent mouseEvent) {
        DataBase.getLoginedUser().getGame().setMute(false);
        DataBase.getMediaPlayer().setAutoPlay(true);
        DataBase.getLoginedUser().getGame().setMute(false);
    }

    public void levelSet(MouseEvent mouseEvent) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Level error");
        alert.setContentText("Please enter a valid number between 1 to 3");
        if (level.getText() == null) {
            alert.showAndWait();
            return;
        } else if (!CheckController.isNumber(level.getText())) {
            alert.showAndWait();
            return;
        }
        int levelNumber = Integer.parseInt(level.getText());
        if (levelNumber < 1 || levelNumber > 3) {
            alert.showAndWait();
        } else {
            DataBase.getLoginedUser().getGame().setLevel(levelNumber);
            alert.setAlertType(Alert.AlertType.INFORMATION);
            alert.setTitle("Successful");
            alert.setContentText("We set the level successfully");
            alert.showAndWait();
        }

    }

    public void shoutKeySet(MouseEvent mouseEvent) {
        DataBase.getLoginedUser().getGame().setShoutKey(shoutKey.getText());
    }

    public void freezeKey(MouseEvent mouseEvent) {
        DataBase.getLoginedUser().getGame().setFreezeKey(freezeKey.getText());
    }

    public void grayStyle(MouseEvent mouseEvent) {
        DataBase.getLoginedUser().getGame().setBlackAndWhite(true);
    }

    public void cancelGrayStyle(MouseEvent mouseEvent) {
        DataBase.getLoginedUser().getGame().setBlackAndWhite(false);
    }

    public void mapNumberSet(MouseEvent mouseEvent) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Map error");
        alert.setContentText("Please enter a valid number between 1 to 3");
        if (map.getText() == null) {
            alert.showAndWait();
            return;
        } else if (!CheckController.isNumber(map.getText())) {
            alert.showAndWait();
            return;
        }
        int mapNumber = Integer.parseInt(map.getText());
        if (mapNumber < 1 || mapNumber > 3) {
            alert.showAndWait();
        } else {
            DataBase.getLoginedUser().getGame().setMapNumber(mapNumber);
            alert.setAlertType(Alert.AlertType.INFORMATION);
            alert.setTitle("Successful");
            alert.setContentText("We set the map successfully");
            alert.showAndWait();
        }
    }
}
