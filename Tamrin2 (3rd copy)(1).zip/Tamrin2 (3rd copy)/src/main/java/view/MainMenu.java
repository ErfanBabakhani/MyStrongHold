package view;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.DataBase;
import model.Game;

import java.io.FileNotFoundException;

public class MainMenu {
    private Stage mainStage;
    private Pane pane;
    private Scene profileScene;

    public MainMenu(Pane pane, Stage mainStage, Scene profileScene) {
        this.mainStage = mainStage;
        this.pane = pane;
        this.profileScene = profileScene;
    }

    public void start() throws FileNotFoundException {
        Scene scene = new Scene(pane);
        DataBase.setMainMenuScene(scene);
        DataBase.getLoginedUser().setGame(new Game(2, 1, 9, false, false, "Space", "Tab"));
        if (DataBase.getLoginedUser().getProfileAvatar() != null) {
            DataBase.getLoginedUser().getProfileAvatar().setCenterX(50);
            DataBase.getLoginedUser().getProfileAvatar().setCenterY(50);
            pane.getChildren().add(DataBase.getLoginedUser().getProfileAvatar());
        }
        mainStage.setScene(scene);
    }

}
