package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.DataBase;
import javafx.scene.effect.ColorAdjust.*;
import javafx.scene.media.*;

import java.net.URL;

public class LoginMenu extends Application {
    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        DataBase.setStage(primaryStage);
        URL url = LoginMenu.class.getResource("/FXML/LoginMenu.fxml");
        BorderPane borderPane = FXMLLoader.load(url);

        DataBase.borderPane = borderPane;


        Media media = new Media(LoginMenu.class.getResource("/Music/Inspiring-Dreams.mp3").toExternalForm());
        MediaPlayer mediaPlayer = new MediaPlayer(media);
        mediaPlayer.setAutoPlay(true);
        DataBase.setMediaPlayer(mediaPlayer);
        Scene scene = new Scene(borderPane);
        primaryStage.setScene(scene);
        DataBase.setLoginMenuScene(scene);
        primaryStage.show();
    }
}