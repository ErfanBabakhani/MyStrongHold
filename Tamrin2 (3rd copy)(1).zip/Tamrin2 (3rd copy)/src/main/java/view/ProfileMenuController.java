package view;

import controller.CheckController;
import controller.LoginController;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import model.DataBase;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Random;

public class ProfileMenuController {

    public TextField avatarUrl;
    public TextField newName;
    public TextField newPassword;


    public void Back() {
        DataBase.getStage().setScene(DataBase.getLoginMenuScene());
        DataBase.getMediaPlayer().play();
    }

    public void setThespeceficAvatar(MouseEvent mouseEvent) throws FileNotFoundException {
        try {
            DataBase.getLoginedUser().setProfileAvatar(avatarUrl.getText());
        } catch (Exception ignored) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid file");
            alert.setContentText("Please choose valid path");
            alert.showAndWait();
        }
    }

    public void rename(MouseEvent mouseEvent) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        if (DataBase.getLoginedUser().getUsername().equals("Guest") && DataBase.getLoginedUser().getPassword().equals("123")) {
            alert.setTitle("Guest user");
            alert.setContentText("Guest can not change name");
            alert.showAndWait();
            return;
        }
        if (newName == null || newName.getText().length() < 4) {
            alert.setTitle("Invalid name");
            alert.setContentText("Please enter a name with at least 4 char");
            alert.showAndWait();
        } else if (DataBase.getUserNameByName(newName.getText()) != null) {
            alert.setTitle("Invalid name");
            alert.setContentText("This name is already exist");
            alert.showAndWait();
        } else {
            DataBase.getLoginedUser().setUsername(newName.getText());
            alert.setAlertType(Alert.AlertType.INFORMATION);
            alert.setTitle("Successful");
            alert.setContentText("We successfully change your name");
            alert.showAndWait();
        }
    }

    public void changePassword(MouseEvent mouseEvent) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Weak password");
        alert.setContentText("Please enter strong password");
        if (CheckController.checkThePassword(newPassword.getText())) {
            DataBase.getLoginedUser().setPassword(newPassword.getText());
            alert.setAlertType(Alert.AlertType.INFORMATION);
            alert.setTitle("Successful");
            alert.setContentText("We change your password successfully");
            alert.showAndWait();
        } else {
            alert.showAndWait();
        }
    }

    public void Delete(MouseEvent mouseEvent) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Invalid user");
        alert.setContentText("User is Guest so can not delete");
        if (DataBase.getLoginedUser().getUsername().equals("Guest") || DataBase.getLoginedUser().getPassword().equals("123")) {
            alert.showAndWait();
            return;
        }
        DataBase.removeFromAllUser(DataBase.getLoginedUser());
        DataBase.setLoginedUser(null);
        this.Back();
    }

    public void randomAvatar(MouseEvent mouseEvent) throws FileNotFoundException {
        Random random = new Random();
        int index = random.nextInt(1, 6);
        String url = ProfileMenuController.class.getResource("/Image/A" + index + ".png").toExternalForm();
        DataBase.getLoginedUser().setProfileAvatar(0, url);
    }

    public void mainMenu(MouseEvent mouseEvent) throws IOException {
        changeSecen();
    }

    public void changeSecen() throws IOException {
        Pane pane = FXMLLoader.load(LoginController.class.getResource("/FXML/MainMenu.fxml"));
        MainMenu mainMeu = new MainMenu(pane, DataBase.getStage(), DataBase.getStage().getScene());
        mainMeu.start();
    }

}
