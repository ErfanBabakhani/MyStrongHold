package view;

import controller.GameController;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class GameMenu {
    private static Stage mainStage;
    private Pane pane;

    public GameMenu(Pane pane, Stage mainStage) {
        this.mainStage = mainStage;
        this.pane = pane;
    }

    public void start() {
        playMedia();
        Rocket rocket = setRocket();
        GameMenuController.setMap(this);
        this.mainStage.setScene(new Scene(pane));
        Label label = new Label();
        ProgressBar freezeBar = new ProgressBar();
        freezeBar.setLayoutX(200);
        freezeBar.setProgress(1);
        DataBase.getLoginedUser().getGame().setFreezeBarLable(freezeBar);
        label.setText("Remain balls : " + DataBase.getLoginedUser().getGame().getPlayerBalls() + " Score : " + 0);
        label.setLayoutX(0);
        label.setLayoutY(0);
        pane.getChildren().add(label);
        pane.getChildren().add(freezeBar);
        DataBase.getLoginedUser().startTime = System.currentTimeMillis();

        rocketStart(rocket, label);
        if (DataBase.getLoginedUser().getGame().isBlackAndWhite())
            makeImageBlackAndWhite();
    }

    private void playMedia() {
        MediaPlayer mediaPlayer = new MediaPlayer(new Media(GameMenuController.class.getResource("/Music/Here We Go.mp3").toExternalForm()));
        if (!DataBase.getLoginedUser().getGame().isMute()) {
            mediaPlayer.setOnEndOfMedia(new Runnable() {
                public void run() {
                    mediaPlayer.seek(Duration.ZERO);
                }
            });
            mediaPlayer.setStartTime(Duration.seconds(0));
            mediaPlayer.setStopTime(Duration.seconds(100000));
            mediaPlayer.play();
            mediaPlayer.setAutoPlay(true);
        }
        DataBase.getLoginedUser().getGame().setMediaPlayer(mediaPlayer);
    }

    private void makeImageBlackAndWhite() {
        Image gray = toGrayScale(DataBase.getLoginedUser().getGame().getMainCircle().getImagePattern().getImage());
        DataBase.getLoginedUser().getGame().getMainCircle().setImagePattern(new ImagePattern(gray));
        Image grayRocket = toGrayScale(DataBase.getLoginedUser().getGame().getRocket().getImagePattern().getImage());
        DataBase.getLoginedUser().getGame().getRocket().setImagePattern(new ImagePattern(grayRocket));
        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(700), actionEvent -> doBlackAndWhite()));
        DataBase.getLoginedUser().getGame().getAllTimeLines().add(timeline);
        timeline.setCycleCount(200);
        timeline.play();
    }

    private void doBlackAndWhite() {
        ArrayList<LittleBall> littleBalls = DataBase.getLoginedUser().getGame().getLittleBall();
        ArrayList<Line_Blue> lineBlues = DataBase.getLoginedUser().getGame().getLineBlues();
        for (int i = 0; i < littleBalls.size(); i++) {
            Image gray = toGrayScale(littleBalls.get(i).getBall().getImage());
            littleBalls.get(i).setBall(new ImagePattern(gray));
        }
        for (int i = 0; i < lineBlues.size(); i++) {
            Image gray = toGrayScale(lineBlues.get(i).getImagePattern().getImage());
            lineBlues.get(i).setImagePattern(new ImagePattern(gray));
        }
    }


    public static Image toGrayScale(Image sourceImage) {
        PixelReader pixelReader = sourceImage.getPixelReader();

        int width = (int) sourceImage.getWidth();
        int height = (int) sourceImage.getHeight();

        WritableImage grayImage = new WritableImage(width, height);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int pixel = pixelReader.getArgb(x, y);

                int alpha = ((pixel >> 24) & 0xff);
                int red = ((pixel >> 16) & 0xff);
                int green = ((pixel >> 8) & 0xff);
                int blue = (pixel & 0xff);

                int grayLevel = (int) (0.2162 * red + 0.7152 * green + 0.0722 * blue);
                int gray = (alpha << 24) + (grayLevel << 16) + (grayLevel << 8) + grayLevel;

                grayImage.getPixelWriter().setArgb(x, y, gray);
            }
        }
        return grayImage;
    }


    public void setMap1() {
        MainCircle mainCircle = setMainCircle();
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 30);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 45);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 180);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 40);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        startRotation(mainCircle);
    }

    public void setMap2() {
        MainCircle mainCircle = setMainCircle();
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 90);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 130);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 20);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 60);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 25);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        startRotation(mainCircle);
    }

    public void setMap3() {
        MainCircle mainCircle = setMainCircle();
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 15);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 30);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 30);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 60);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 15);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        oneRotate(mainCircle, 15);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));

        oneRotate(mainCircle, 20);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));

        oneRotate(mainCircle, 20);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));

        oneRotate(mainCircle, 45);
        setLittleBallAndLine().setBall(new ImagePattern(new Image(GameMenu.class.getResource("/Image/OrangeBall.png").toExternalForm())));
        startRotation(mainCircle);
    }

    private void startRotation(MainCircle mainCircle) {
        int level = DataBase.getLoginedUser().getGame().getLevel();
        int circleSpeed = GameController.getTheCircleSpeed(level);
        DataBase.getLoginedUser().getGame().setCircleSpeed(circleSpeed);
        double windSpeed = GameController.getTheWindSpeed(level);
        Rotate rotate = new Rotate();
        rotate.setAngle(windSpeed);
        rotate.setPivotX(900);
        rotate.setPivotY(350);
        rotationStart(mainCircle, circleSpeed, rotate);
        faze2(rotate);
        faze3(rotate);
        faze4();
    }

    private void faze4() {
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(5), actionEvent -> changeTheRocketDegree()));
        DataBase.getLoginedUser().getGame().getAllTimeLines().add(timeline);
        timeline.setCycleCount(-1);
        timeline.play();
    }

    private void changeTheRocketDegree() {
        if (isFaze4Start()) {
            double random = new Random().nextDouble(-15, 15);
            DataBase.getLoginedUser().getGame().getRocket().setRocketDegree(random);
            DataBase.getLoginedUser().getGame().getRocket().setRotate(random);
        }
    }

    private void moveLeft(Rocket rocket) {
        if (rocket.getLayoutX() < -680)
            return;
        rocket.setLayoutX(rocket.getLayoutX() - 10);
    }

    private void moveRight(Rocket rocket) {
        if (rocket.getLayoutX() > 530)
            return;
        rocket.setLayoutX(rocket.getLayoutX() + 10);
    }

    private void faze3(Rotate rotate) {
        Timeline timelineVisible = new Timeline(new KeyFrame(Duration.seconds(1), actionEvent -> makeBallVisible(DataBase.getLoginedUser().getGame())));
        DataBase.getLoginedUser().getGame().getAllTimeLines().add(timelineVisible);
        timelineVisible.setCycleCount(-1);
        timelineVisible.play();
    }

    private void makeBallVisible(Game game) {
        if (!isFaze3Start())
            return;
        if (game.isVisible()) {
            for (int i = 0; i < game.getLittleBall().size(); i++) {
                game.getLittleBall().get(i).setRadius(game.getLittleBall().get(i).getRadius() * 0.001);
                game.getLineBlues().get(i).setHeight(game.getLineBlues().get(i).getHeight() * 0.001);
            }
            game.setVisible(false);
        } else {
            for (int i = 0; i < game.getLittleBall().size(); i++) {
                if (game.getLittleBall().get(i).getRadius() > 1)
                    continue;
                game.getLittleBall().get(i).setRadius(game.getLittleBall().get(i).getRadius() * 1000);
                game.getLineBlues().get(i).setHeight(game.getLineBlues().get(i).getHeight() * 1000);

            }
            game.setVisible(true);
        }
    }

    private void rotationStart(MainCircle mainCircle, int circleSpeed, Rotate rotate) {
        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(circleSpeed), actionEvent -> rotateTheCircle(rotate, DataBase.getLoginedUser().getGame().getLineBlues(), DataBase.getLoginedUser().getGame().getLittleBall(), mainCircle)));
        DataBase.getLoginedUser().getGame().setTimeline(timeline);
        timeline.setCycleCount(-1);
        timeline.setAutoReverse(true);
        timeline.play();
    }


    private LittleBall setLittleBallAndLine() {
        setLineBlue();
        return setLittleBall();
    }

    private Line_Blue setLineBlue() {
        Line_Blue lineBlue = new Line_Blue();
        DataBase.getLoginedUser().getGame().getLineBlues().add(lineBlue);
        this.pane.getChildren().add(lineBlue);
        return lineBlue;
    }

    private Line_Blue setLineBluePlayer2() {
        Game game = DataBase.getLoginedUser().getGame();

        Line_Blue lineBlue = new Line_Blue();

        DataBase.getLoginedUser().getGame().getLineBlues().add(lineBlue);
        this.pane.getChildren().add(lineBlue);
        return lineBlue;
    }

    private LittleBall setLittleBall() {
        LittleBall littleBall = new LittleBall("/Image/littleBall.png");
        DataBase.getLoginedUser().getGame().getLittleBall().add(littleBall);
        this.pane.getChildren().add(littleBall);
        return littleBall;
    }

    private void setLittleBallPlayer2() {
        LittleBall littleBall = new LittleBall("/Image/LittleBall2.png");
        Game game = DataBase.getLoginedUser().getGame();
        game.getLittleBall().add(littleBall);
        this.pane.getChildren().add(littleBall);
    }

    private Rocket setRocket() {
        Rocket rocket = new Rocket();
        DataBase.getLoginedUser().getGame().setRocket(rocket);
        this.pane.getChildren().add(rocket);
        return rocket;
    }

    private void faze2(Rotate rotate) {

        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(4), actionEvent -> randomRotate(rotate)));
        DataBase.getLoginedUser().getGame().getAllTimeLines().add(timeline);
        timeline.setCycleCount(-1);
        timeline.play();
        Timeline timelineBigger = new Timeline(new KeyFrame(Duration.seconds(1), actionEvent -> makeBallBigger(DataBase.getLoginedUser().getGame())));
        DataBase.getLoginedUser().getGame().setTimelineBigger(timelineBigger);
        DataBase.getLoginedUser().getGame().getAllTimeLines().add(timelineBigger);
        timelineBigger.setCycleCount(-1);
        timelineBigger.play();
    }

    private void makeBallBigger(Game game) {
        if (!isFaze2Start())
            return;
        ArrayList<LittleBall> allLittleBalls = DataBase.getLoginedUser().getGame().getLittleBall();
        if (allLittleBalls.get(0).isItBigger()) {
            for (int i = 0; i < allLittleBalls.size(); i++) {
                allLittleBalls.get(0).setItBigger(false);
                allLittleBalls.get(i).setRadius(allLittleBalls.get(i).getRadius() * ((double) 10 / 11));
            }
        } else {
            for (int i = 0; i < allLittleBalls.size(); i++) {
                allLittleBalls.get(i).setItBigger(true);
                allLittleBalls.get(i).setRadius(allLittleBalls.get(i).getRadius() * 1.1);
            }
        }
        if (GameController.isGameOver(pane)) {
            DataBase.getLoginedUser().getGame().getTimelineBigger().stop();
            setGameOver(DataBase.getLoginedUser().getGame().getFirstBalls());
        } else if (DataBase.getLoginedUser().getGame().getPlayerBalls() == 0) {
            DataBase.getLoginedUser().getGame().getTimelineBigger().stop();
            setGameWin(DataBase.getLoginedUser().getGame().getFirstBalls());
        }
    }

    private boolean isFaze2Start() {
        if (DataBase.getLoginedUser().getGame().getPlayerBalls() > (DataBase.getLoginedUser().getGame().getFirstBalls() / 4) * 3)
            return false;
        return true;
    }

    private boolean isFaze3Start() {
        if (DataBase.getLoginedUser().getGame().getPlayerBalls() > (DataBase.getLoginedUser().getGame().getFirstBalls() / 4) * 2)
            return false;
        return true;
    }

    private boolean isFaze4Start() {
        if (DataBase.getLoginedUser().getGame().getPlayerBalls() > (DataBase.getLoginedUser().getGame().getFirstBalls() / 4))
            return false;
        return true;
    }

    private void randomRotate(Rotate rotate) {

        if (!isFaze2Start())
            return;
        Random random = new Random();
        double randNumber = random.nextDouble(1, 2);
        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(randNumber), actionEvent -> changeRotateDirection(rotate)));
        DataBase.getLoginedUser().getGame().getAllTimeLines().add(timeline);
        timeline.setCycleCount(1);
        timeline.play();
    }

    private void changeRotateDirection(Rotate rotate) {

        DataBase.getLoginedUser().getGame().getTimeline().stop();
        rotate.setAxis(Rotate.Z_AXIS);
        Rotate rotate1 = new Rotate();
        rotate1.setAngle(-rotate.getAngle());

        rotate1.setPivotX(rotate.getPivotX());
        rotate1.setPivotY(rotate.getPivotY());


        rotationStart(DataBase.getLoginedUser().getGame().getMainCircle(), DataBase.getLoginedUser().getGame().getCircleSpeed(), rotate1);
        faze2(rotate1);
    }

    private void oneRotate(MainCircle mainCircle, double degree) {
        Rotate rotate = new Rotate();
        rotate.setAngle(degree);
        rotate.setPivotX(900);
        rotate.setPivotY(350);
        mainCircle.getTransforms().add(rotate);
        ArrayList<Line_Blue> lineBlues = DataBase.getLoginedUser().getGame().getLineBlues();
        for (int i = 0; i < lineBlues.size(); i++) {
            lineBlues.get(i).getTransforms().add(rotate);
        }
        ArrayList<LittleBall> LittleBall = DataBase.getLoginedUser().getGame().getLittleBall();
        for (int i = 0; i < LittleBall.size(); i++) {
            LittleBall.get(i).getTransforms().add(rotate);
        }
    }

    private MainCircle setMainCircle() {
        MainCircle mainCircle = new MainCircle();
        DataBase.getLoginedUser().getGame().setMainCircle(mainCircle);
        this.pane.getChildren().add(mainCircle);
        return mainCircle;
    }

    private void rotateTheCircle(Rotate rotate, ArrayList<Line_Blue> lineBlues, ArrayList<LittleBall> littleBalls, MainCircle mainCircle) {

        for (int i = 0; i < lineBlues.size(); i++) {
            lineBlues.get(i).getTransforms().add(rotate);
        }
        for (int i = 0; i < littleBalls.size(); i++) {
            littleBalls.get(i).getTransforms().add(rotate);
        }
        mainCircle.getTransforms().add(rotate);
    }

    private void rocketStart(Rocket rocket, Label label) {
        this.pane.getChildren().get(0).requestFocus();
        Game game = DataBase.getLoginedUser().getGame();
        int playerBalls = game.getPlayerBalls();
        rocket.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                if (event.getCode().getName().equals(game.getShoutKey())) {
                    if (!shout())
                        return;
                    if (GameController.isGameOver(pane)) {
                        setGameOver(playerBalls);
                        return;
                    }
                    game.setPlayerBalls(game.getPlayerBalls() - 1);
                    if (game.getPlayerBalls() <= 0) {
                        setGameWin(playerBalls);
                        return;
                    }
                    label.setText("Remain balls : " + game.getPlayerBalls() + " Score : " + getTheCurrentScore());

                } else if (event.getCode().getName().equals(game.getFreezeKey())) {
                    freeze();
                    System.out.println("Tab");

                } else if (event.getCode().getName().equals("Right")) {
                    if (isFaze4Start())
                        moveRight(rocket);
                } else if (event.getCode().getName().equals("Left")) {
                    if (isFaze4Start())
                        moveLeft(rocket);
                } else if (event.getCode().getName().equals("Enter")) {
                    shoutPlayer2();
                    if (GameController.isGameOver(pane)) {
                        setGameOver(playerBalls);
                        return;
                    }
                    game.setPlayerBalls(game.getPlayerBalls() - 1);
                    if (game.getPlayerBalls() <= 0) {
                        setGameWin(playerBalls);
                        return;
                    }
                    label.setText("Remain balls : " + game.getPlayerBalls());
                } else if (event.getCode().getName().equals("Z")) {
                    stopAllTimeLines();
                    try {
                        showPause();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    playAllTimeLines();
                }
            }
        });
        DataBase.getLoginedUser().getGame().setFirstBalls(playerBalls);
    }

    private int getTheCurrentScore() {
        Game game = DataBase.getLoginedUser().getGame();
        return (game.getFirstBalls() - game.getPlayerBalls()) * game.getLevel();
    }

    private void showPause() throws IOException {
        Stage stage = new Stage();
        DataBase.setPauseStage(stage);
        Pane pane1 = FXMLLoader.load(GameMenu.class.getResource("/FXML/Pause.fxml"));
        Scene scene = new Scene(pane1);
        stage.setScene(scene);
        stage.showAndWait();
    }

    private void setGameOver(int playerBalls) {
        Image image = new Image(GameMenu.class.getResource("/Image/Red3.png").toExternalForm(), 1800, 1000, false, false);
        if (DataBase.getLoginedUser().getGame().isBlackAndWhite()) {
            doBlackAndWhite();
            image = toGrayScale(image);
        }

        setTheBackGround(new Background(setBackGroundImage(image)));
        changeScene();
        setTheLastGameTime();
        setTheEndAlert("Game over", "You are lose \n" + "Time of Game : " + DataBase.getLoginedUser().getTheLastGameEndTime() + " Millis");
        setTheMusic(DataBase.getLoginedUser().getGame());
        resetBall(playerBalls);
    }

    private void setGameWin(int playerBalls) {
        Image image = new Image(GameMenu.class.getResource("/Image/green.png").toExternalForm(), 1800, 1000, false, false);
        if (DataBase.getLoginedUser().getGame().isBlackAndWhite()) {
            doBlackAndWhite();
            image = toGrayScale(image);
        }

        setTheBackGround(new Background(setBackGroundImage(image)));
        setTheLastGameTime();
        changeScene();
        setTheEndAlert("Congratulation", "You are win\n" + "Time of Game : " + DataBase.getLoginedUser().getTheLastGameEndTime() + " Millis");
        setTheMusic(DataBase.getLoginedUser().getGame());
        setTheScore(playerBalls);
        resetBall(playerBalls);
    }

    public static void resetBall(int playerBall) {
        DataBase.getLoginedUser().getGame().setPlayerBalls(playerBall);
    }

    private void setTheScore(int playerBalls) {
        Game game = DataBase.getLoginedUser().getGame();
        DataBase.getLoginedUser().setScore(DataBase.getLoginedUser().getScore() + playerBalls * game.getLevel());
        System.out.println(DataBase.getLoginedUser().getScore());
    }

    private void setTheLastGameTime() {
        long endTime = System.currentTimeMillis();
        long time = endTime - DataBase.getLoginedUser().startTime;
        DataBase.getLoginedUser().setTheLastGameEndTime(time);
    }

    private boolean shout() {
        Game game = DataBase.getLoginedUser().getGame();
        Rocket rocket = game.getRocket();
        double radius = game.getMainCircle().getRadius();
        if (rocket.getLayoutX() == game.getMainCircle().getLayoutX()) {
            System.out.println("TODO");
            if (rocket.getLayoutX() > (game.getMainCircle().getLayoutX() - radius) && rocket.getLayoutX() < (game.getMainCircle().getLayoutX() + radius)) {

                makeShout(rocket);
                changeTheFreezeBar();
                return true;
            }
        }
        return false;

    }

    private void changeTheFreezeBar() {
        Game game = DataBase.getLoginedUser().getGame();
        if (game.getFreezeBar() < 100) {
            game.setFreezeBar(game.getFreezeBar() + 20);
            updateFreezeBar(game.getFreezeBar() + 20);
        }
    }

    private void shoutPlayer2() {
        Game game = DataBase.getLoginedUser().getGame();
        Rocket rocket = game.getRocket();
        double radius = game.getMainCircle().getRadius();
        if (rocket.getLayoutX() == game.getMainCircle().getLayoutX()) {
            System.out.println("TODO");
            if (rocket.getLayoutX() > (game.getMainCircle().getLayoutX() - radius) && rocket.getLayoutX() < (game.getMainCircle().getLayoutX() + radius)) {
                makeShoutPlayer2(rocket);
                changeTheFreezeBar();
            }
        }

    }

    private void makeShout(Rocket rocket) {
        double degree = rocket.getRocketDegree();
        oneRotate(DataBase.getLoginedUser().getGame().getMainCircle(), degree);
        setLineBlue();
        setLittleBall();
    }

    private void makeShoutPlayer2(Rocket rocket) {
        double degree = rocket.getRocketDegree();
        oneRotate(DataBase.getLoginedUser().getGame().getMainCircle(), degree);
        oneRotate(DataBase.getLoginedUser().getGame().getMainCircle(), 180);
        setLineBluePlayer2();
        setLittleBallPlayer2();
        oneRotate(DataBase.getLoginedUser().getGame().getMainCircle(), 180);
    }

    private void freeze() {
        Game game = DataBase.getLoginedUser().getGame();
        if (game.getFreezeBar() == 100) {
            doFreeze(game);
            game.setFreezeBar(0);
            updateFreezeBar(0);
        }
    }

    private void updateFreezeBar(int rate) {
        DataBase.getLoginedUser().getGame().getFreezeBarLable().setProgress((double) rate / 100);
    }

    private void doFreeze(Game game) {
        game.getTimeline().setRate(.1);
        int speedTime = getTheSpeedTimeByLevel(DataBase.getLoginedUser().getGame().getLevel());
        MediaPlayer mediaPlayer = new MediaPlayer(new Media(GameMenu.class.getResource("/Music/freeze.mp3").toExternalForm()));
        mediaPlayer.setCycleCount(1);
        mediaPlayer.play();
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(speedTime), actionEvent -> cancelFreeze(game.getTimeline())));
        DataBase.getLoginedUser().getGame().getAllTimeLines().add(timeline);
        timeline.setCycleCount(1);
        timeline.play();
    }

    private int getTheSpeedTimeByLevel(int level) {
        if (level == 1)
            return 7;
        else if (level == 2)
            return 5;
        else
            return 3;
    }

    private void cancelFreeze(Timeline timeline) {
        timeline.setRate(1);
    }

    public static void changeScene() {
        Game game = DataBase.getLoginedUser().getGame();
        stopAllTimeLines();
        game.getMediaPlayer().stop();
        mainStage.show();
    }

    private void setTheBackGround(Background background) {
        pane.setBackground(background);
    }

    public static void stopAllTimeLines() {

        ArrayList<Timeline> allTimeLines = DataBase.getLoginedUser().getGame().getAllTimeLines();
        DataBase.getLoginedUser().getGame().getTimeline().stop();
        DataBase.getLoginedUser().getGame().getTimeline().setCycleCount(0);
        DataBase.getLoginedUser().getGame().getTimelineBigger().stop();
        DataBase.getLoginedUser().getGame().getTimelineBigger().setCycleCount(0);
        System.out.println(allTimeLines.size());
        for (int i = 0; i < allTimeLines.size(); i++) {
            allTimeLines.get(i).stop();
            allTimeLines.get(i).setCycleCount(0);
        }
    }

    public static void playAllTimeLines() {
        ArrayList<Timeline> allTimeLines = DataBase.getLoginedUser().getGame().getAllTimeLines();
        DataBase.getLoginedUser().getGame().getTimeline().play();
        for (int i = 0; i < allTimeLines.size(); i++) {
            allTimeLines.get(i).play();
        }
    }

    private static void setTheEndAlert(String title, String context) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(context);
        stopAllTimeLines();
        alert.showAndWait();
    }

    public static void setTheMusic(Game game) {
        if (!game.isMute()) {
            DataBase.getMediaPlayer().setAutoPlay(true);
            DataBase.getMediaPlayer().play();
        }
        DataBase.getStage().setScene(DataBase.getMainMenuScene());
    }

    private static BackgroundImage setBackGroundImage(Image image) {
        BackgroundImage backgroundImage = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        return backgroundImage;
    }

}
