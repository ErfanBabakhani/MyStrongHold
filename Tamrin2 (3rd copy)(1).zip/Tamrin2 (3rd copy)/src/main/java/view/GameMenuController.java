package view;

import controller.GameController;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import model.DataBase;
import model.Game;

import java.util.ArrayList;

public class GameMenuController {

    public static void setMap(GameMenu gameMenu) {
        int map = DataBase.getLoginedUser().getGame().getMapNumber();
        if (map == 1)
            gameMenu.setMap1();
        else if (map == 2)
            gameMenu.setMap2();
        else if (map == 3)
            gameMenu.setMap3();
    }


    public static void start() {

    }

    public void back(MouseEvent mouseEvent) {
        GameMenu.stopAllTimeLines();
        DataBase.getStage().setScene(DataBase.getMainMenuScene());
        DataBase.setStage(DataBase.getStage());
        DataBase.getPauseStage().close();
        DataBase.getLoginedUser().getGame().getMediaPlayer().stop();
        GameMenu.resetBall(DataBase.getLoginedUser().getGame().getFirstBalls());
        DataBase.getLoginedUser().getGame().getTimeline().setCycleCount(0);
        GameMenu.setTheMusic(DataBase.getLoginedUser().getGame());
        DataBase.getLoginedUser().getGame().setAllTimeLine(new ArrayList<>());
        DataBase.getStage().show();
    }

    public void mute(MouseEvent mouseEvent) {
        DataBase.getLoginedUser().getGame().getMediaPlayer().stop();
        DataBase.getLoginedUser().getGame().setMute(true);
        DataBase.getPauseStage().close();
    }

    public void unMute(MouseEvent mouseEvent) {
        DataBase.getLoginedUser().getGame().getMediaPlayer().play();
        DataBase.getLoginedUser().getGame().setMute(false);
        DataBase.getPauseStage().close();
    }

    public void help(MouseEvent mouseEvent) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Key help");
        Game game = DataBase.getLoginedUser().getGame();
        String string = "shout : " + game.getShoutKey() + "\n" + "freeze : " + game.getFreezeKey();
        alert.setContentText(string);
        alert.showAndWait();
    }

    public void firstMusic(MouseEvent mouseEvent) {
        Game game = DataBase.getLoginedUser().getGame();
        game.getMediaPlayer().stop();
        game.setMediaPlayer(new MediaPlayer(new Media(GameController.class.getResource("/Music/Here We Go.mp3").toExternalForm())));
        game.getMediaPlayer().play();
        game.getMediaPlayer().setAutoPlay(true);
        game.getMediaPlayer().setCycleCount(-1);
    }

    public void secondMusic(MouseEvent mouseEvent) {
        Game game = DataBase.getLoginedUser().getGame();
        game.getMediaPlayer().stop();
        game.setMediaPlayer(new MediaPlayer(new Media(GameController.class.getResource("/Music/HEROICCC.mp3").toExternalForm())));
        game.getMediaPlayer().play();
        game.getMediaPlayer().setAutoPlay(true);
        game.getMediaPlayer().setCycleCount(-1);
    }

    public void thirdMusic(MouseEvent mouseEvent) {
        Game game = DataBase.getLoginedUser().getGame();
        game.getMediaPlayer().stop();
        game.setMediaPlayer(new MediaPlayer(new Media(GameController.class.getResource("/Music/Sky.mp3").toExternalForm())));
        game.getMediaPlayer().play();
        game.getMediaPlayer().setAutoPlay(true);
        game.getMediaPlayer().setCycleCount(-1);
    }
}
