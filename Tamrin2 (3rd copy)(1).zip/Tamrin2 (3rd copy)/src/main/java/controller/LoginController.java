package controller;

import model.DataBase;
import model.User;

public class LoginController {
    public static String register(String userName, String password,boolean[] check) {
        if(userName==null||userName.length()<4){
            check[0]=false;
            return "Please enter a username with at least 4 char";
        }
        if (DataBase.getUserNameByName(userName) != null){
            check[0]=false;
            return "This userName is already exist";
        }
        DataBase.addToAllUsers(new User(userName,password));
        return "";
    }
}
