package controller;

import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import model.DataBase;
import model.Game;
import model.LittleBall;

public class GameController {
    public static boolean isGameOver(Pane pane) {
        Game game = DataBase.getLoginedUser().getGame();

        for (int i = 1; i < pane.getChildren().size() - 1; i++) {
            for (int j = i + 1; j < pane.getChildren().size(); j++) {
                if (pane.getChildren().get(i) instanceof Rectangle || pane.getChildren().get(j) instanceof Rectangle)
                    continue;
                if (pane.getChildren().get(i).getBoundsInParent().intersects(pane.getChildren().get(j).getBoundsInParent())) {
                    System.out.println(pane.getChildren().get(i));
                    System.out.println(pane.getChildren().get(j));
                    return true;
                }
            }
        }
        return false;
    }


    public static int getTheCircleSpeed(int level) {
        if (level == 1)
            return 9;
        else if (level == 2)
            return 6;
        else return 3;
    }

    public static double getTheWindSpeed(int level) {
        if (level == 1)
            return 1.6;
        else if (level == 2)
            return 2;
        else return 2.4;
    }

}
