package controller;

import model.DataBase;
import model.User;

import java.util.ArrayList;

public class MainController {
    public static ArrayList<User> getTheRankUsers() {

        ArrayList<User> allRanks = sortUsersByScore();
        System.out.println("AllRanks " + allRanks.size());
        ArrayList<User> finalRanks = sortUsersByTime(allRanks);
        ArrayList<User> ranks = new ArrayList<>();
        for (int i = 0; i < finalRanks.size() && i < 10; i++) {
            ranks.add(finalRanks.get(i));
        }
        return ranks;
    }

    private static ArrayList<User> sortUsersByScore() {
        ArrayList<User> all = DataBase.getAllUsers();
        for (int i = 0; i < all.size() - 1; i++) {
            for (int j = i + 1; j < all.size(); j++) {
                if (all.get(j).getScore() > all.get(i).getScore()) {
                    swap(all, i, j);
                }
            }
        }
        return all;
    }

    private static ArrayList<User> sortUsersByTime(ArrayList<User> all) {
        for (int i = 0; i < all.size(); i++) {
            for (int j = i + 1; j < all.size() - 1; j++) {
                if (all.get(j).getTheLastGameEndTime() < all.get(i).getTheLastGameEndTime())
                    swap(all, i, j);
            }
        }
        return all;
    }


    private static void swap(ArrayList<User> all, int target, int mustBeReplaced) {
        User temp = all.get(target);
        all.set(target, all.get(mustBeReplaced));
        all.set(mustBeReplaced, temp);
    }
}
