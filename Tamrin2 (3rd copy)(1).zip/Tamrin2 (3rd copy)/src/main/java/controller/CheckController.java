package controller;

import enums.LoginMenuCommand;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckController {
    public static boolean checkThePassword(String password) {
        return isMach(password, LoginMenuCommand.isStrongPass.getPattern());
    }

    private static boolean isMach(String mustBeChecked, Pattern pattern) {
        Matcher matcher = pattern.matcher(mustBeChecked);
        return matcher.find();
    }

    public static boolean isNumber(String mustBeChecked) {
        try {
            Integer.parseInt(mustBeChecked);
        } catch (Exception exception) {
            return false;
        }
        return true;
    }
}
