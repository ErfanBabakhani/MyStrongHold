package model;

import java.io.FileNotFoundException;

public class User {
    private long theLastGameEndTime = 0;
    private String username;
    private String password;
    private int score = 0;
    private ProfileAvatar profileAvatar;
    private int Level1 = 0;
    private int Level2 = 0;
    private int Level3 = 0;
    public long startTime;
    private Game game;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public ProfileAvatar getProfileAvatar() {
        return profileAvatar;
    }

    public void setProfileAvatar(int x, String url) {
        this.profileAvatar = new ProfileAvatar(x, url);
        System.out.println(this.profileAvatar);
    }

    public void setProfileAvatar(String url) throws FileNotFoundException {
        this.profileAvatar = new ProfileAvatar(url);
        System.out.println(this.profileAvatar);
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public long getTheLastGameEndTime() {
        return theLastGameEndTime;
    }

    public void setTheLastGameEndTime(long theLastGameEndTime) {
        this.theLastGameEndTime = theLastGameEndTime;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

}
