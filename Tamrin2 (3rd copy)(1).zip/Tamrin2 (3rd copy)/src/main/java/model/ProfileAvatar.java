package model;

import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class ProfileAvatar extends Circle {

    private String url;
    private ImagePattern imagePattern;

    public ProfileAvatar(int x, String url) {
        super(x + 40, 100, 45);
        setImagePattern(new ImagePattern(new Image(url)));
        this.setFill(this.getImagePattern());
        this.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                DataBase.getLoginedUser().setProfileAvatar(x, url);
            }
        });
    }

    public ProfileAvatar(String url) throws FileNotFoundException {
        super(40, 300, 45);
        InputStream stream = new FileInputStream(url);
        Image image = new Image(stream);
        this.imagePattern = new ImagePattern(image);
        this.setFill(imagePattern);
    }


    public String url() {
        return url;
    }

    public void setImagePattern(ImagePattern imagePattern) {
        this.imagePattern = imagePattern;
    }

    public ImagePattern getImagePattern() {
        return imagePattern;
    }
}
