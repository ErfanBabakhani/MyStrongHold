package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Line_Blue extends Rectangle {
    private ImagePattern imagePattern = new ImagePattern(new Image(Line_Blue.class.getResource("/Image/Line_Blue.png").toExternalForm()));

    public Line_Blue() {
        super(900, 400, 1, 180);
        this.setFill(imagePattern);
    }

    public ImagePattern getImagePattern() {
        return imagePattern;
    }

    public void setImagePattern(ImagePattern imagePattern) {
        this.imagePattern = imagePattern;
        this.setFill(imagePattern);
    }
}
