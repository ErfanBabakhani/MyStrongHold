package model;

import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

import java.util.ArrayList;

public class DataBase {
    private static MediaPlayer mediaPlayer;
    private static Stage stage;
    private static Scene loginMenuScene;
    private static Scene mainMenuScene;
    private static ArrayList<User> allUsers = new ArrayList<>();
    public static BorderPane borderPane;
    private static User loginedUser;
    private static Stage pauseStage;

    public static Stage getStage() {
        return stage;
    }

    public static void setStage(Stage stage) {
        DataBase.stage = stage;
    }

    public static User getUserNameByName(String username) {
        for (int i = 0; i < allUsers.size(); i++) {
            if (allUsers.get(i).getUsername().equals(username))
                return allUsers.get(i);
        }
        return null;
    }

    public static void addToAllUsers(User user) {
        DataBase.allUsers.add(user);
    }

    public static void removeFromAllUser(User user) {
        ArrayList<User> allUsers = DataBase.allUsers;
        for (int i = 0; i < allUsers.size(); i++) {
            if (allUsers.get(i) == user) {
                allUsers.remove(allUsers.get(i));
                return;
            }
        }
    }

    public static Scene getLoginMenuScene() {
        return loginMenuScene;
    }

    public static void setLoginMenuScene(Scene loginMenuScene) {
        DataBase.loginMenuScene = loginMenuScene;
    }

    public static User getLoginedUser() {
        return loginedUser;
    }

    public static void setLoginedUser(User loginedUser) {
        DataBase.loginedUser = loginedUser;
    }

    public static ArrayList<User> getAllUsers() {
        return allUsers;
    }

    public static Scene getMainMenuScene() {
        return mainMenuScene;
    }

    public static void setMainMenuScene(Scene mainMenuScene) {
        DataBase.mainMenuScene = mainMenuScene;
    }

    public static MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }

    public static void setMediaPlayer(MediaPlayer mediaPlayer) {
        DataBase.mediaPlayer = mediaPlayer;
    }

    public static Stage getPauseStage() {
        return pauseStage;
    }

    public static void setPauseStage(Stage pauseStage) {
        DataBase.pauseStage = pauseStage;
    }
}
