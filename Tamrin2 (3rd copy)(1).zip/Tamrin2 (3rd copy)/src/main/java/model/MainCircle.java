package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

public class MainCircle extends Circle {
    private ImagePattern imagePattern = new ImagePattern(new Image(MainCircle.class.getResource("/Image/MainCircle.png").toExternalForm()));
    private LittleBall littleBall;

    public MainCircle() {
        super(900, 350, 65);
        this.setFill(imagePattern);
    }

    public ImagePattern getImagePattern() {
        return imagePattern;
    }

    public void setImagePattern(ImagePattern imagePattern) {
        this.imagePattern = imagePattern;
        this.setFill(imagePattern);
    }
}
