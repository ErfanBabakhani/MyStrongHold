package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

public class LittleBall extends Circle {
    private ImagePattern ball = new ImagePattern(new Image(LittleBall.class.getResource("/Image/littleBall.png").toExternalForm()));
    private boolean isItBigger = false;

    public LittleBall(String url) {
        super(900, 580, 15);
        this.ball = new ImagePattern(new Image(LittleBall.class.getResource(url).toExternalForm()));
        this.setFill(ball);
    }

    public void setColor() {

    }

    public ImagePattern getBall() {
        return ball;
    }

    public void setBall(ImagePattern ball) {
        this.ball = ball;
        this.setFill(getBall());
    }

    public boolean isItBigger() {
        return isItBigger;
    }

    public void setItBigger(boolean itBigger) {
        isItBigger = itBigger;
    }


}
