package model;

import javafx.animation.Timeline;
import javafx.scene.control.ProgressBar;
import javafx.scene.media.MediaPlayer;

import java.util.ArrayList;

public class Game {
    private int level;
    private int mapNumber;
    private int playerBalls;
    private int firstBalls = playerBalls;
    private boolean isMute;
    private boolean isBlackAndWhite;
    private String shoutKey;
    private String freezeKey;
    private int freezeBar = 100;
    private ProgressBar freezeBarLable;
    private ArrayList<Line_Blue> lineBlues = new ArrayList<>();
    private ArrayList<LittleBall> LittleBall = new ArrayList<>();
    private Rocket rocket;
    private Timeline timeline;
    private MediaPlayer mediaPlayer;
    private MainCircle mainCircle;
    private Timeline timelineBigger;
    private ArrayList<Timeline> allTimeLine = new ArrayList<>();
    private int circleSpeed;
    private boolean isVisible = true;

    public Game(int level, int mapNumber, int playerBalls, boolean isMute, boolean isBlackAndWhite, String shoutKey, String freezeKey) {
        this.level = level;
        this.mapNumber = mapNumber;
        this.playerBalls = playerBalls;
        this.isMute = isMute;
        this.isBlackAndWhite = isBlackAndWhite;
        this.shoutKey = shoutKey;
        this.freezeKey = freezeKey;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getMapNumber() {
        return mapNumber;
    }

    public void setMapNumber(int mapNumber) {
        this.mapNumber = mapNumber;
    }

    public int getPlayerBalls() {
        return playerBalls;
    }

    public void setPlayerBalls(int playerBalls) {
        this.playerBalls = playerBalls;
    }

    public boolean isMute() {
        return isMute;
    }

    public void setMute(boolean mute) {
        isMute = mute;
    }

    public boolean isBlackAndWhite() {
        return isBlackAndWhite;
    }

    public void setBlackAndWhite(boolean blackAndWhite) {
        isBlackAndWhite = blackAndWhite;
    }

    public String getShoutKey() {
        return shoutKey;
    }

    public void setShoutKey(String shoutKey) {
        this.shoutKey = shoutKey;
    }

    public String getFreezeKey() {
        return freezeKey;
    }

    public void setFreezeKey(String freezeKey) {
        this.freezeKey = freezeKey;
    }

    public ArrayList<Line_Blue> getLineBlues() {
        return lineBlues;
    }

    public void setLineBlues(ArrayList<Line_Blue> lineBlues) {
        this.lineBlues = lineBlues;
    }

    public ArrayList<model.LittleBall> getLittleBall() {
        return LittleBall;
    }

    public void setLittleBall(ArrayList<model.LittleBall> littleBall) {
        LittleBall = littleBall;
    }

    public Rocket getRocket() {
        return rocket;
    }

    public void setRocket(Rocket rocket) {
        this.rocket = rocket;
    }

    public Timeline getTimeline() {
        return timeline;
    }

    public void setTimeline(Timeline timeline) {
        this.timeline = timeline;
    }

    public MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }

    public void setMediaPlayer(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    public MainCircle getMainCircle() {
        return mainCircle;
    }

    public void setMainCircle(MainCircle mainCircle) {
        this.mainCircle = mainCircle;
    }

    public int getFirstBalls() {
        return firstBalls;
    }

    public void setFirstBalls(int firstBalls) {
        this.firstBalls = firstBalls;
    }

    public Timeline getTimelineBigger() {
        return timelineBigger;
    }

    public void setTimelineBigger(Timeline timelineBigger) {
        this.timelineBigger = timelineBigger;
    }

    public ArrayList<Timeline> getAllTimeLines() {
        return this.allTimeLine;
    }

    public int getCircleSpeed() {
        return circleSpeed;
    }

    public void setCircleSpeed(int circleSpeed) {
        this.circleSpeed = circleSpeed;
    }

    public boolean isVisible() {
        return isVisible;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }

    public int getFreezeBar() {
        return freezeBar;
    }

    public void setFreezeBar(int freezeBar) {
        this.freezeBar = freezeBar;
    }

    public ProgressBar getFreezeBarLable() {
        return freezeBarLable;
    }

    public void setFreezeBarLable(ProgressBar freezeBarLable) {
        this.freezeBarLable = freezeBarLable;
    }

    public void setAllTimeLine(ArrayList<Timeline> allTimeLine) {
        this.allTimeLine = allTimeLine;
    }
}
