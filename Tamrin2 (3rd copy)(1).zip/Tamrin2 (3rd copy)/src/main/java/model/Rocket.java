package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Rocket extends Rectangle {
    private ImagePattern imagePattern = new ImagePattern(new Image(Line_Blue.class.getResource("/Image/Rocket.png").toExternalForm()));
    private double rocketDegree = 0;

    public Rocket() {
        super(860, 680, 120, 120);
        setFill(imagePattern);
    }

    public double getRocketDegree() {
        return rocketDegree;
    }

    public void setRocketDegree(double rocketDegree) {
        this.rocketDegree = rocketDegree;
    }

    public ImagePattern getImagePattern() {
        return imagePattern;
    }

    public void setImagePattern(ImagePattern imagePattern) {
        this.imagePattern = imagePattern;
        this.setFill(imagePattern);
    }
}
